<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>DTSENA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>

    <?php echo $__env->yieldContent('nav'); ?>
    <div class="main">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email address</label>
            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
          </div>
    </div>
    <?php echo $__env->yieldContent('footer'); ?>

</body>
</html>
<?php /**PATH C:\Users\maico\Documents\Github\dtsena2024\resources\views/app.blade.php ENDPATH**/ ?>