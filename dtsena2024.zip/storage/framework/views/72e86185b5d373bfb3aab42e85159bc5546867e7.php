<?php $__env->startSection('content'); ?>
    <div class="d-flex" style="width: calc(100% - 250px); height: 100vh;margin-left: 250px">
        
        <div class="container p-3">
            <div class="row">
                <div class="col-md-8">
                    <section class="canales-publicos mt-4">
                        <div class="d-flex gap-2 align-items-center">
                            <h3>Canales públicos</h3>
                            <?php if(Auth::check()): ?>
                            <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Crear
                                canal</a>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <?php $__currentLoopData = $canales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <div class="card mt-2">
                                        <div class="card-body">
                                            <h5><?php echo e($item->nombre_canal); ?></h5>
                                            <p>Total de dispositivos</p>
                                            <p><?php echo e($item->lugar); ?></p>
                                        </div>
                                        <div class="card-footer">
                                            <a href="/panel/mis-canales/canal/<?php echo e($item->id); ?>">Ver canal</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                </div>
                <div class="col-md-4">
                    <section class="info mt-5">
                        <div class="card card-body">
                            <h3 class="fw-bold">Sobre DTSENA</h3>
                            <p>DTSENA es una plataforma diseñada específicamente para la recolección de datos del cultivo de pepino poinsset, en el marco del proyecto SENNOVA 2023 titulado "Implementación de un sistema de fertirriego automatizado para un cultivo de hortalizas". Esta plataforma posibilita la recopilación de datos tanto a través de un canal DTSENA desde un dispositivo como desde el entorno web.</p>
                            <img class="img-fluid" src="<?php echo e(asset('img/logo_sennova.png')); ?>" alt="">
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php if(Auth::check()): ?>
        <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Creación de canal</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="/registro-canal" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-2">
                            <label for="nombre_canal">Nombre del canal</label>
                            <input type="text" name="nombre_canal" id="nombre_canal" class="form-control"
                                placeholder="Ingrese nombre del canal" required>
                        </div>
                        <div class="form-group mb-2">
                            <label for="lugar">Lugar, ciudad de monitoreo</label>
                            <input type="text" name="lugar" id="lugar" class="form-control"
                                placeholder="Ingrese el lugar o la ciudad donde está realizando el monitoreo" required>
                        </div>
                        <input type="hidden" readonly name="id_user" id="id_user" class="form-control" value="<?php echo e(Auth::user()->id); ?>" required>
                        <div class="tipo">
                            <label class="mb-2" for="tipo">Visibilidad</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="tipo" id="flexRadioDefault1"
                                    value="público" checked>
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Público
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="tipo" value="privado"
                                    id="flexRadioDefault2">
                                <label class="form-check-label" for="flexRadioDefault2">
                                    Privado
                                </label>
                            </div>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button class="btn btn-primary">Crear canal</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maico\Documents\Github\dtsena2024\resources\views/panel/home.blade.php ENDPATH**/ ?>