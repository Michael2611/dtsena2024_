<?php $__env->startSection('content'); ?>
    <div class="contenido-login">
        <div class="form">
            <h1>Registro DTSENA</h1>
            <div class="card border-0">
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <ul>
                            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <form action="/registro" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre(s)</label>
                            <input type="text" class="form-control" id="nombre" name="nombre"
                                placeholder="Ingrese nombres">
                        </div>
                        <div class="mb-3">
                            <label for="apellido" class="form-label">Apellido(s)</label>
                            <input type="text" class="form-control" id="apellido" name="apellido"
                                placeholder="Ingrese apellidos">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Correo electronico</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@sena.edu.co">
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="d-flex mb-3">
                            <button class="btn btn-primary w-100" type="submit">Registrar</button>
                        </div>
                        <div class="d-flex flex-column align-items-center justify-content-end gap-2">
                            <a href="">Recuperar contraseña</a>
                            <a href="">Nuevo usuario</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maico\Documents\Github\dtsena2024\resources\views/auth/registro.blade.php ENDPATH**/ ?>