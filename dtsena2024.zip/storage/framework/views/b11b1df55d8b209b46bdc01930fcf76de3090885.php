<div class="sidebar">
    <div class="d-flex gap-2 align-items-center">
        <img src="<?php echo e(asset('img/logo_sena.png')); ?>" style="width: 60px; height: 60px;">
        <h3 class="fw-bold mt-2" style="color: #fff">DTSENA</h3>
    </div>
    <a href="/panel"><i class="bi bi-house"></i> Home</a>
    <?php if(Auth::check()): ?><a href="/panel/mis-canales/<?php echo e(Auth::user()->id); ?>"><i class="bi bi-database-up"></i> Mis Canales</a><?php endif; ?>
    <a href="#"><i class="bi bi-bar-chart"></i> Reportes</a>
    <a href="#"><i class="bi bi-info-circle"></i> Ayuda</a>
    <?php if(!Auth::check()): ?>
    <a href="/login"><i class="bi bi-box-arrow-right"></i> Iniciar sesión</a>
    <?php endif; ?>
    <?php if(Auth::check()): ?>
    <form action="/logout" method="post">
        <?php echo csrf_field(); ?>
        <button><i class="bi bi-box-arrow-left"></i> Cerrar sesión</button>
    </form>
    <?php endif; ?>

</div>
<?php /**PATH C:\Users\maico\Documents\Github\dtsena2024\resources\views/panel/sidebar/sidebar.blade.php ENDPATH**/ ?>