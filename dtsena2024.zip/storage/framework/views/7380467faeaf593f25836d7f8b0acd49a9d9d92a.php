<?php $__env->startSection('content'); ?>
    <div class="d-flex" style="width: calc(100% - 250px); height: 100vh;margin-left: 250px">
        
        <div class="container p-3 mt-2">
            <h1 class="fw-bold">Mis canales</h1>
            <div class="card">
                <div class="card-body p-4">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nombre canal</th>
                                <th>Lugar - Ubicación</th>
                                <th>Tipo visibilidad</th>
                                <th>---</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1?>
                            <?php $__currentLoopData = $canales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($item->nombre_canal); ?></td>
                                    <td><?php echo e($item->lugar); ?></td>
                                    <td><?php echo e($item->tipo); ?></td>
                                    <td>
                                        <div class="d-flex gap-2 justify-content-center align-items-center">
                                            <a class="btn btn-primary" href="/panel/mis-canales/canal/<?php echo e($item->id); ?>">Ver</a>
                                            <form action="/panel/canal/<?php echo e($item->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger mt-3" type="submit">Eliminar</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\maico\Documents\Github\dtsena2024\resources\views/panel/canal/mis-canales.blade.php ENDPATH**/ ?>